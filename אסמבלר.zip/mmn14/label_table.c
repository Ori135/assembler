/*file contain functions to handle labeles and create label table*/

#include "assembler.h"
#include "label_table.h"
#include "data_transfer.h"
#include <stdlib.h>
#include <string.h>


/*================================================ label functions ===============================================*/

label* create_label(char* name, int val, int is_data, int type, int is_entry, int line_num)
{
	label* node; /*temp node, will be returnd*/
	int name_size = (NULL_TERMINATOR_SIZE+strlen(name)); /*size to be allocated including null terminator*/	

	if((node=malloc(sizeof(label)))==NULL){ /*allocate memory for new node*/
		fprintf(stderr,"failed to allocate memory in create_label()\n");
		return NULL; 
	}
	
	if((node->name=(char*)calloc(name_size, sizeof(char)))==NULL){ /*allocate memory for name segment*/
		fprintf(stderr,"failed to allocate memory in create_label()\n");
		return NULL; 
	}

	/*update diffrent segments*/
	strcpy(node->name, name);
	node->val = val;
	node->type = type;
	node->is_data = is_data;
	node->is_entry =OFF;
	node->line_num = line_num;
	node->next=NULL;

	return node;
}

int add_label_to_end(label** head, label* node)
{
	label* temp = *head; /*temp to go over list*/

	if(node ==NULL){
		return ERROR;
	}

	if(*head==NULL){ /*empty list - add to start*/
		*head = node;
		return OK;
	}

	for(temp= *head; temp->next; temp= temp->next)
	{
		if(!strcmp(temp->name, node->name)) /*label already exsist*/
		{
			fprintf(stderr,"ERROR: label '%s' defined twice:\n in line %d\nin line: %d\n\n",
					node->name, temp->line_num, node->line_num);
			return ERROR;
		}
	}/*temp points to last item*/
	
	if(!strcmp(temp->name, node->name)) /*check last node*/
	{
		fprintf(stderr,"ERROR: label '%s' defined twice:\n in line %d\nin line: %d\n\n",
					node->name, temp->line_num, node->line_num);
		return ERROR;
	}
	
	temp->next = node;
	return OK;
}

int new_label(label **head, char* name, int val, int is_data, int type, int is_entry, int line_num)
{
	return (add_label_to_end(head, create_label(name, val, is_data, type, is_entry, line_num)));
}

int delete_label_node(label* node)
{
	if(node) /*if not null*/
	{
		free(node->name);
		free(node);
	}
	return OK;
}


int delete_label_list(label* head)
{
	label* temp = head;
	while(head) /*head not null*/
	{
		temp = head->next; /*advance temp*/
		delete_label_node(head); /*delete head*/
		head=temp; /*new head*/
	}
	return OK;
}

int update_data(label* head, int IC)
{
	label* node=head;
	int counter=0;

	while(node)
	{
		if(node->is_data){ /*if label is data type*/
			node->val += IC; /*update value*/
			counter++;
		}
		node= node->next; /*advance node*/

	}
	return counter; 
}

int print_ent(label* head, FILE* pt)
{
	int counter=0; /*count num of nodes printed*/
	label* node = head;
	char* temp =NULL;
	while(node)
	{
		if(node->is_entry)
		{
			temp = binary_to_b32(node->val); /*get base 32 value*/
			if(temp){
				fprintf(pt, "%s\t%s\n", node->name, temp); /*print name in chars and value in base 32*/
				free(temp); /*free allocated memory*/
				counter++; /*advance counter*/
			}
		}
		node = node->next; /*advance node*/
	}
	return counter;
}


int search_type(label* head, int flag)
{
	label* node =head;
	
	while(node) /*check every node in list*/
	{
		if (flag == EXTERNAL){ /*looking for external labels*/
			if(node->type == EXTERNAL){
			return TRUE;
			}
		}
		if( flag == ENTRY){
			if(node->is_entry){
			return TRUE;
			}
		}
		node = node->next; /*advance node*/
	}
	return FALSE; /*node not found*/
}

int search_label(label* head, char* str)
{
	label* temp =head;
	while(temp)
	{
		if(!strcmp(temp->name, str)) /*label found*/
		{
			return temp->val;	
		}
		temp = temp->next; /*advance temp*/
	}
	return NOT_FOUND;
}
	

/*========================================= ent_req functions =========================================*/

l_type* create_l_type(char* name, int val, int line_num, int type) /*type is entry or extern*/
{
	l_type* node; /*temp node, will be returnd*/
	int name_size = (NULL_TERMINATOR_SIZE+strlen(name)); /*size to be allocated including null terminator*/	

	if((node=malloc(sizeof(l_type)))==NULL){ /*allocate memory for new node*/
		fprintf(stderr,"failed to allocate memory in create_label()\n");
		return NULL; 
	}
	
	if((node->name=(char*)calloc(name_size, sizeof(char)))==NULL){ /*allocate memory for name segment*/
		fprintf(stderr,"failed to allocate memory in create_label()\n");
		return NULL; 
	}

	/*update values*/
	strcpy(node->name, name);
	node->val = val;
	node->line_num = line_num;
	node->type = type;
	node->next=NULL;

	return node;
}

int add_l_type_to_end(l_type** head, l_type* node)
{
	l_type* temp = *head; /*temp to go over list*/

	if(node ==NULL){
		return ERROR;
	}

	if(*head==NULL){ /*empty list - add to start*/
		*head = node;
		return OK;
	}

	for(temp= *head; temp->next; temp= temp->next)
	{
		if(!strcmp(temp->name, node->name) && node->type==ENTRY) /*label already exsist*/
		{
			fprintf(stderr,"WARNING: label '%s' defined as entry twice:\n in line %d\nin line: %d\n\n",
					node->name, temp->line_num, node->line_num);
			return OK;
		}
	}/*temp points to last item*/
	
	if(!strcmp(temp->name, node->name) && node->type==ENTRY) /*check last node*/
	{
		fprintf(stderr,"WARNING: label '%s' defined as entry twice:\n in line %d\nin line: %d\n\n",
					node->name, temp->line_num, node->line_num);
		return OK;
	}
	
	temp->next = node;
	return OK;
}

int new_l_type(l_type** head, char* name, int val, int line_num, int type)
{
	return (add_l_type_to_end(head, create_l_type(name, val, line_num, type)));
}

int delete_l_type_node(l_type* node)
{
	if(node) /*if not null*/
	{
		free(node->name);
		free(node);
	}
	return OK;
}

int delete_l_type_list(l_type* head)
{
	l_type* temp = head;
	while(head) /*head not null*/
	{
		temp = head->next; /*advence temp*/
		delete_l_type_node(head); /*delete head*/
		head=temp; /*new head*/
	}
	return OK;
}



int update_ent(label* label_head, l_type* ent_head)
{
	l_type* ent = ent_head;
	label* label = label_head;
	int flag =OK; /* will return */
	int label_found; /*flag to check whether label exist*/

	while(ent) /*a loop to go over all entry req*/
	{
		label_found = FALSE; /*new entry req*/
		label = label_head;
		while(label) /*a loop to go over all labels*/
		{
			if(!(strcmp(label->name, ent->name)) && ent->type == ENTRY) /*label found*/
			{
				label_found = TRUE; /*turn on flag*/

				if(label->type ==EXTERNAL){ /*eror, a label can not be both entry and external*/
					/*error message*/
					fprintf(stderr,"EROR: label '%s' can not be both external and entry type\n", label->name);
					fprintf(stderr, "defined in: %d\n requsted as entry at line: %d\n\n",
								 label->line_num, ent->line_num);
					flag = ERROR;
				}
				else{ /* label not external*/
					label->is_entry = TRUE; /*update label*/
				}
			}
			label = label->next; /*advance label*/
		}

		if(label_found == FALSE) /*eror: missing label*/
		{
			fprintf(stderr,"EROR: label '%s' does not exist\nlabel requsted as entry at line: %d\n\n"
						, ent->name, ent->line_num);
			flag = ERROR;	
		}
		
		ent = ent->next; /*advance entry*/
	}

	return flag;
}

int print_ext(l_type* ext_head, FILE* pt)
{
	int counter=0; /*count num of nodes printed*/
	l_type* node = ext_head;
	char* temp =NULL;
	while(node)
	{
		if(node->type == EXTERNAL)
		{
			temp = binary_to_b32(node->val); /*get base 32 line that label has been used in*/
			if(temp){
				fprintf(pt, "%s\t%s\n", node->name, temp); /*print name in chars and value in base 32*/
				free(temp); /*free allocated memory*/
				counter++; /*advance counter*/
			}
		}
		node = node->next; /*advance node*/
	}
	return counter;
}


