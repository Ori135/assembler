#include <stdlib.h>
#include "first_pass.h"
#include <string.h>
#include "input.h"
#include "data_transfer.h"


int code_data(char* line, int* i, int instruction_index, word* data_image, int* DC, int line_num)
{
	int is_first_op = TRUE;
	char* operand=NULL;
	int op_type=0;
	int is_empty = ON;
	int cnt =0; /*counter for data unstruction - count number of operands*/

	if(instruction_index != DATA){
		if(instruction_index == STRUCT){
			operand = get_operand(line, i, line_num, FALSE, is_first_op, &is_empty, FALSE); /*get operand*/
			if(operand==NULL){
				return ERROR;
			}
			op_type = what_method(operand, line_num,TRUE); /*operand type*/
			if(op_type != IMMEDATE_ATM){
				free(operand);
				if(op_type!=NOT_FOUND){
					fprintf(stderr,"ERROR: in line %d illegal operand '%s' ",line_num,operand);  						fprintf(stderr,"for struct, expected number\n");
				}
				return ERROR;
			}
			
			data_image[(*DC)++].field = read_sign(operand); /*save first operand*/
			is_first_op = FALSE;
		}
		/*get string*/
		operand = get_operand(line, i, line_num, TRUE, is_first_op, &is_empty, FALSE); /*get operand*/
		if(operand==NULL){
			return ERROR;
		}

		if(!is_string(operand)){
			fprintf(stderr,"ERROR: in line %d illegal operand '%s', expected string\n",line_num,operand);
			free(operand);
			return ERROR;
		}
	
		/*save string*/
		for(*i=1; *i<strlen(operand)-1; (*i)++){ /*from first char to last not including " chars*/
			data_image[(*DC)++].field = operand[*i];
		}
		data_image[(*DC)++].field = 0; /*NULL terminator*/
		data_image[FLAG_INDEX].field = ON;
	
		return OK;
	}
	else{ /*data type*/
		operand = get_operand(line, i, line_num, FALSE, is_first_op, &is_empty, TRUE); /*get operand*/
		cnt++;
		if(operand==NULL){
			if(is_empty){
				fprintf(stderr,"ERROR: in line %d missing operand\n", line_num);
			}
			return ERROR;
		}
		is_first_op = FALSE;
		while(operand){
			if(what_method(operand, line_num, TRUE) != IMMEDATE_ATM){
				fprintf(stderr,"ERROR: in line %d illegal operand '%s' \n",line_num,operand);
				fprintf(stderr,"for data instruction: argument must be a number\n");
				free(operand);
				return ERROR;
			}
			
			data_image[(*DC)++].field = read_sign(operand); /*save first operand*/
			operand = get_operand(line, i, line_num, FALSE, is_first_op, &is_empty, TRUE); /*get operand*/
			if(operand){
				cnt++;
			}
		} /*end loop*/
		if(comma_check(line, cnt, line_num) == ERROR){
				return ERROR;
		}
		data_image[FLAG_INDEX].field = OFF;
		
	}
	return OK;
}

int code_action_first_word(char* line, int* i, int  action_index, word* instruction_image, int* IC, int line_num)
{
	int operand_counter = num_of_operands(action_index);
	char* operand;
	int origin_ATM=NOT_FOUND; /*origin Adrres Type Method*/
	int des_ATM =NOT_FOUND; /*destenation Adrres Type Method*/
	int is_empty=ON;

	/*save action op code*/
	instruction_image[(*IC)].field += index_to_binary(action_index, OP_CODE);

	if(operand_counter == 0){ /* no operands*/
		ignore_space(line,i);
		operand = get_str(line,i);
		if(operand){ /*not NULL*/
			fprintf(stderr, "ERROR: in line %d excessive text after end of comand\n", line_num);
			return ERROR;
		}
	}
	if(operand_counter == 1){ /*one operand*/
		operand = get_operand(line, i, line_num, TRUE, TRUE, &is_empty, FALSE); /*get operand*/
		if(operand==NULL){
			if(is_empty){
				fprintf(stderr,"ERROR: in line %d missing operand\n", line_num);
			}
			return ERROR;
		}
		des_ATM = what_method(operand, line_num,FALSE);
		if(des_ATM == NOT_FOUND){
			free(operand);
			return ERROR;
		}
		instruction_image[(*IC)].field += index_to_binary(des_ATM, DES_ATM); /*save action_code*/
	}
	if(operand_counter == 2){ /*two operands*/
		operand = get_operand(line, i, line_num, FALSE, TRUE, &is_empty, FALSE); /*get origin operand*/
		if(operand==NULL){
			if(is_empty){
				fprintf(stderr,"ERROR: in line %d missing operand\n",line_num);
			}
			return ERROR;
		}
		origin_ATM = what_method(operand, line_num,FALSE);
		if(origin_ATM == NOT_FOUND){
			fprintf(stderr,"ERROR: in line %d missing operand\n",line_num);
			free(operand);
			return ERROR;
		}
		instruction_image[(*IC)].field += index_to_binary(origin_ATM, ORIGIN_ATM); /*save ATM*/

		operand = get_operand(line, i, line_num, TRUE, FALSE, &is_empty, FALSE); /*get destenation operand*/
		if(operand==NULL){
			if(is_empty){
				fprintf(stderr,"ERROR: in line %d missing operand\n", line_num);
			}
			free(operand);
			return ERROR;
		}
		des_ATM = what_method(operand, line_num,FALSE);
		if(des_ATM == NOT_FOUND){
			fprintf(stderr,"ERROR: in line %d missing operand\n",line_num);
			free(operand);
			return ERROR;
		}
		instruction_image[(*IC)].field += index_to_binary(des_ATM, DES_ATM); /*save ATM*/
	}

	/*check operand-action compatibility */
	if(legal_op_action(action_index, origin_ATM, des_ATM, line_num) == ERROR){ 
		return ERROR;
	}

	/*are bits are 0, no need to intilaize*/

	(*IC)+=  calc_L(origin_ATM, des_ATM); /*update instruction counter*/

	return OK;
}

int calc_L(int origin_ATM, int des_ATM)
{
	 int L=MIN_L; /*min value for only first word*/

	/*add origin word to L*/
	if(origin_ATM != NOT_FOUND) 
	{   /*action use origin operand*/
		if(origin_ATM == STRUCT_ATM){
			L++; /*struct ATM require more words*/
		 }
		 L++; /*all ATM require at least another word*/
	}
	
	/*add destenation word to L*/
	if(des_ATM != NOT_FOUND) 
	{   /*action use destenation operand*/
		if(des_ATM ==STRUCT_ATM){
			L++; /*struct ATM require more words*/
		 }
		 L++; /*all ATM require at least another word*/
	}

	if(des_ATM == REGISTER_ATM && origin_ATM == REGISTER_ATM)
	{
		L--; /*2 registers can be used in the same word*/
	}
	
	return L;

}


int speical_label_instruction(char* line, int* i, int index, label** label, l_type** lt, int* IC, int line_num)
{

	char* name;
	int is_empty=ON;
	name = get_operand(line, i, line_num,TRUE,TRUE,&is_empty, FALSE);
	
	if(name==NULL){ /*ilegal line*/
		free(name);
		if(is_empty){
			fprintf(stderr,"ERROR: in line %d missing operand\n",line_num);
		}
		return ERROR;
	}

	if(is_legal_label(name, line_num,ON) == ERROR){ /*ilegal label*/
		free(name);
		return ERROR;
	}
	
	if(index == EXTERNAL){ /*extern label*/
		if(new_label(label, name, 0, OFF, EXTERNAL, OFF,line_num) == ERROR){ /*new label*/
			free(name);
			return ERROR;
		}
		free(name);
		return OK;
	}
	if(index == ENTRY){ /*entry label*/
		if(new_l_type(lt, name,0, line_num, ENTRY) == ERROR){
			free(name);
			return ERROR;
		}
		free(name);
		return OK;
	}
	return ERROR; /*wrong index*/
}


int legal_op_action(int action, int origin_ATM, int des_ATM, int line_num)
{
	int i=0; /*index*/
	int flag=OFF; /*signal if ATM found */

	static int origin_table[][NUM_OF_ACTIONS] = { /*contain all legal ATM for each action origin operand*/
				{IMMEDATE_ATM,FORWARD_ATM,STRUCT_ATM,REGISTER_ATM}, /*mov action*/
				{IMMEDATE_ATM,FORWARD_ATM,STRUCT_ATM,REGISTER_ATM}, /*cmp action*/
				{IMMEDATE_ATM,FORWARD_ATM,STRUCT_ATM,REGISTER_ATM}, /*add action*/
				{IMMEDATE_ATM,FORWARD_ATM,STRUCT_ATM,REGISTER_ATM}, /*sub action*/
				{NOT_FOUND,END}, /*not action*/
				{NOT_FOUND,END}, /*clr action*/
				{FORWARD_ATM,STRUCT_ATM,END}, /*lea action*/
				{NOT_FOUND,END}, /*inc action*/
				{NOT_FOUND,END}, /*dec action*/
				{NOT_FOUND,END}, /*jmp action*/
				{NOT_FOUND,END}, /*bne action*/
				{NOT_FOUND,END}, /*get action*/
				{NOT_FOUND,END}, /*prn action*/
				{NOT_FOUND,END}, /*jsr action*/
				{NOT_FOUND,END}, /*rts action*/
				{NOT_FOUND,END} /*hlt action*/
				};
				/*"END" used to stop search*/
				
	static int des_table[][NUM_OF_ACTIONS] = { /*contain all legal ATM for each action destenation operand*/
				{FORWARD_ATM,STRUCT_ATM,REGISTER_ATM,END}, /*mov action*/
				{IMMEDATE_ATM,FORWARD_ATM,STRUCT_ATM,REGISTER_ATM}, /*cmp action*/
				{FORWARD_ATM,STRUCT_ATM,REGISTER_ATM,END}, /*add action*/
				{FORWARD_ATM,STRUCT_ATM,REGISTER_ATM,END}, /*sub action*/
				{FORWARD_ATM,STRUCT_ATM,REGISTER_ATM,END}, /*not action*/
				{FORWARD_ATM,STRUCT_ATM,REGISTER_ATM,END}, /*clr action*/
				{FORWARD_ATM,STRUCT_ATM,REGISTER_ATM,END}, /*lea action*/
				{FORWARD_ATM,STRUCT_ATM,REGISTER_ATM,END}, /*inc action*/
				{FORWARD_ATM,STRUCT_ATM,REGISTER_ATM,END}, /*dec action*/
				{FORWARD_ATM,STRUCT_ATM,REGISTER_ATM,END}, /*jmp action*/
				{FORWARD_ATM,STRUCT_ATM,REGISTER_ATM,END}, /*bne action*/
				{FORWARD_ATM,STRUCT_ATM,REGISTER_ATM,END}, /*get action*/
				{IMMEDATE_ATM,FORWARD_ATM,STRUCT_ATM,REGISTER_ATM}, /*prn action*/
				{FORWARD_ATM,STRUCT_ATM,REGISTER_ATM,END}, /*jsr action*/
				{NOT_FOUND,END}, /*rts action*/
				{NOT_FOUND,END} /*hlt action*/
				};

	/*looking for origin ATM*/
	for(i=0; i<NUM_OF_ATM && origin_table[action][i]!=END; i++){ /*look for ATM*/
		if(origin_table[action][i] == origin_ATM){
			flag = ON;
		}
	}
	
	if(!flag){ /*ATM not found - ilegal ATM*/
		fprintf(stderr,"ERROR: in line: %d illegal origin operand for action\n", line_num);
		return ERROR;
	}

	/*looking for destenation ATM*/
	for(i=0, flag=OFF; i<NUM_OF_ATM && des_table[action][i]!=END; i++){ /*look for ATM*/
		if(des_table[action][i] == des_ATM){
			flag = ON;
		}
	}
	
	if(!flag){ /*ATM not found - ilegal ATM*/
		fprintf(stderr,"ERROR: in line: %d illegal destenation operand for action\n", line_num);
		return ERROR;
	}

	return OK;
}


int comma_check(char* line, int count, int line_num)
{
	int commas = line_comma_count(line, 0); /*number of commas*/


	if(commas >= count){ /*ilegal comma*/
		fprintf(stderr, "ERROR: in line:%d ilegal comma\n",line_num);
		return ERROR;
	}
	count--; /*there is'nt a comma before first operand*/

	if(commas == count){ /*ok*/
		return OK;
	}
	else{ /*count> commas --> missing comma*/
		fprintf(stderr,"ERROR: in line:%d missing comma\n", line_num);
		return ERROR;
	}
}
