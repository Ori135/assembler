/*file contain function to help with first pass*/

#include "assembler.h"
#include "label_table.h"


/*function recive a line, index in line, index of instruction the data_image, line number and pointer to data counter
function code data from line based on instruction index to the data image and update DC
return OK or ERROR, if ERROR found print error message
 */
int code_data(char* line, int* i, int instruction_index, word* data_image, int* DC, int line_num);

/*function recive a line, index in line, index of instruction the instructin_image, line number and pointer to instruction counter
code first binary word for action, and update IC
return ERROR or OK, if ERROR found print error message
*/
int code_action_first_word(char* line, int* i, int  action_index, word* instruction_image, int* IC, int line_num);

/*function recive line, index in line and index of .extern or .entry instruction, head for label and l_type lists, and IC
function add label from line to relevent list and check line for errors
return ERROR or OK, if error found print message
*/
int speical_label_instruction(char* line, int* i, int index, label** label, l_type** lt, int* IC, int line_num);

/*recive index of action, origin ATM, destenatin ATM, line number
check if operand is compatable to action, if not print error message
return OK or ERROR
*/
int legal_op_action(int action, int origin_ATM, int des_ATM, int line_num);

/*function recive index of origin and destenation operands and return L (number of word needed)*/
int calc_L(int origin_ATM, int des_ATM);

/*check if number of commas is compatable with number of operands
used for data instruction
does'nt check comma position
recive number of commas and a line, and line number
if error found - print error messege
return OK or ERROR
*/
int comma_check(char* line, int count, int line_num);


