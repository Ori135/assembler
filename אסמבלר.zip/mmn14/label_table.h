/*this file contain defenition of 2 kinds of nodes in a linked list - both of them made up the label table
contain functions to handle, create and use label table
*/
#ifndef LABEL_LIST
#define LABEL_LIST
/*a node in a linked list that make up the label table*/
typedef struct label_list_node
{
	char* name; /*label name*/
	int val; /*label value*/
	int type; /*external or relocatable*/
	int is_entry; /*flag*/
	int is_data; /*flag- data or code*/
	int line_num; /*store the line in code the label was declered, used in error messages*/
	struct label_list_node* next; /*next item in list*/
} label;
#endif

#ifndef LABEL_TYPE_LIST
#define LABEL_TYPE_LIST
/*a node in a linked list that hold all label names requsted to be entry or all useges of extern labels*/
typedef struct label_type_node /*lt- label type*/
{
	char* name;
	int line_num; /*for entry:store the line in code the label was declered, used in error messages*/
	int val;     /* for .ext file*/
	int type; /*entry or extern*/
	struct label_type_node* next;
} l_type; /*l_type- label type*/
#endif


/*===============================functions for label list====================================*/

/*create a new label with given name, data, type, and is data flag, next will be set to null
is entery wiil be set to OFF by default. return a pointer to the new node, if an error occurred return NULL
*/
label* create_label(char* name, int val,  int is_data, int type, int is_entry, int line_num);


/*add to end of list given temp node, search for end of list from given head pointer
if head is NULL set node as head.
if label already exist print eror message and return ERROR, if node added succsesfully return OK
if node is NULL return error
*/
int add_label_to_end(label** head, label* node);

/*use create_label and add_label_to_end fuctions to create and add new label, return OK or ERROR*/
int new_label(label** head, char* name, int val, int is_data, int type, int is_entry, int line_num);

/*delete given node by free allocated memory
return OK 
*/
int delete_label_node(label* node);


/*delete all node on list starting from head(given node)
return the number of nodes deleted
 */
int delete_label_list(label* head);

/*goes over every node in list, update every data type node: val+=IC
return the nuber of data type nodes in list
*/
int update_data(label* head, int IC);

/* used for .ent file
print given list to given file pointer. 
print relevent data from entery nodes only
return number of nodes printed
*/
int print_ent(label* head, FILE* pt);

/*recive a list and a flag. based on the flag look for external or entry nodes.
goes over every node in the list until found wanted type, if found return TRUE, else FALSE.
*/
int search_type(label* head, int flag);

/*recive a label name and search for it in recived list
return the label's value, if label does'nt exist return NOT_FOUND
*/
int search_label(label* head, char* str);


/*===============================functions for l_type list====================================*/

/*create a new l_type node with given name, next will be set to null
return a pointer to the new node, if an error occurred return NULL
*/
l_type* create_l_type(char* name, int val, int line_num, int type);


/*add to end of list given temp node, search for end of list from given head pointer
if head is NULL set temp as head.
if label already exist print eror message and return ERROR, if node added succsesfully return OK
if node is NULL return error
*/
int add_l_type_to_end(l_type** head, l_type* node);

/*use create_l_type and add_l_type_to_end fuctions to create and add new l_type, return OK or ERROR*/
int new_l_type(l_type** head, char* name, int val, int line_num, int type);

/*delete given node by free allocated memory
return OK or ERROR 
*/
int delete_l_type_node(l_type* node);


/*delete all node on list starting from head(given node)
return the number of nodes deleted
 */
int delete_l_type_list(l_type* head);


/*used in the end of first passage
recive a list of labels and a list of ent_req, update every label found in l_type as entry to entry type
if a label does not exist but found in l_type list print eror message, or if a label is set as external
return ERROR if error occurred, else return OK
*/
int update_ent(label* label_head, l_type* ent_head);

/*print to .ext file
print given list to given file pointer. 
print relevent data from extern nodes only
return number of nodes printed
*/
int print_ext(l_type* ext_head, FILE* pt);







