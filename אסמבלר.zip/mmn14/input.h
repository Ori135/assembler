/*file to handle input and output*/

#include <stdio.h>

#define MAX_LINE_SIZE 81 /*including '\n'*/
#define RESET_VAL 0 /*reset for chars*/

/*macro for print space to wanted file - if space is not NULL prints it*/
#define print_space(fpt,space) if(space!=NULL){\
					fprintf(fpt,"%s",space);\
					free(space);\
					space=NULL;\
				}


/*return file pointer to file with mode, if can not create or open file return NULL
file name will be file name string followed by file name ending string
 */
FILE* open_file(char* file_name, char* name_ending, char* mode);

/*get string from file input
recive a line and return the current str based on static variable that hold position in line
assume static variable to hold position initalized while getting a line
return char pointer to recived word.
*/
char* get_str(char* line, int* position_in_line_pt);

/*get string from file input without including commas
recive a line and return the current str based on static variable that hold position in line
assume static variable to hold position initalized while getting a line
if a string is found - get legal string including spaces untill " found -if not print error message
return char pointer to recived word.
*/
char* get_op(char* line, int* position_in_line_pt, int line_num);

/*get string of space only chars from file input
recive a line and return the current str based on static variable that hold position in line
assume static variable to hold position initalized while getting a line
return char pointer to recived word.
*/
char* get_space(char* line, int* position_in_line_pt);

/*recive a file pointer, a pointer to  char pointer, and a pointer to a flag.
assume pointer to char points to a memory clock big enough 
if EOF found turn flag on.
 read the current line from the file into given chr pointer using fgetc() function
return size of line*/
int read_line(FILE* fpt, char** line, int* EOF_flag);


/*recive file name and check size is valid
return OK ot ERROR 
*/
int valid_file_name(char *arg);

/*recive a char pointer and index in line, change index to point to next non white char
return new index
assume legal index and that str end with \n or EOF
if str is NULL return ERROR*/
int ignore_space(char* str, int* i);

/*
recive a char pointer and it's length, if all chars in char array are white-space 
chars return 1, if pointer is null return TRUE, otherwise return FALSE;
*/
int is_white(char* str, int size);

/*
recive a char and check if it's ascii number in in the digit range
return TRUE if true, else FALSE
*/
int is_digit(char c);

/*
recive a char and check if it's a sign ('-' or '+')
return -1 for negative sign, 1 for positive sign, FALSE if char is not a sign
*/
int is_sign(char c);

/*check if last char in str is ':'
return TRUE if true, else- FALSE
*/
int is_label(char* str);

/*check if str is a register name
return TRUE if true, else- FALSE
*/
int is_reg(char* str);

/*check if str is legal string based om this format: "put_string_here"
if not, return FALSE, else: TRUE
 */
int is_string(char* str);

/*recive action\instruction index. if index is instruction return TRUE else return FALSE*/
int is_instruction(int index);

/*recive a char pointer, assume contain a number and possibly a sign
return integer that represents said number
*/
int read_sign(char* str);

/*recive a char, check if it in the ascii range of printable chars
return 1 or 0;
*/
int is_printable(char ch);

/*check if all chars are numbers, first char can be a sign -+
return TRUE or FALSE
*/
int is_num(char* str);

/*rcive a line and index in line, return the number of commas in line from recived index*/
int line_comma_count(char* line, int i);

