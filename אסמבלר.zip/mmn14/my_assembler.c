#include <stdio.h>
#include "assembler.h"
#include "input.h"
#include <string.h>


/*recive from commad line unlimited number of file names, 
each file is an assembly code with .as ending
translate every file to mechine code in base 32 and create output files:
.ob - object file
.am - code after macro opening
.ent - contain data about entry labels. created only if there is at least one entry label in code
.ext - contain data about external labels. created only if there is at least one external label in code

if there are errors in code print the error type and line in .am file.
if a file is empty object file will not be created

if there is'nt at least one input file return ERROR and print eror message
other wise, return OK
*/
int main(int argc, char* argv[])
{
	int i=1; /*for argv*/

	if(argc<=1){ /*missing file*/
		fprintf(stderr, "fetal eror: no input file\n please use this format: assembler fileName\n");
		return ERROR;
	}
	
	for(; i<argc; i++) /*assembler for every file enterd*/
	{
		/*calling pre_assembler*/
		if(pre_assembler(argv[i])== ERROR)
		{
			continue; /*eror in pre_assembler, continue for next file*/
		}
		
		translate(argv[i]); /*calls for first and second pass*/
	}	

	return OK;
}
