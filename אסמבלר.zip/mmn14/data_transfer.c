#include "assembler.h"
#include "data_transfer.h"
#include "input.h"
#include <string.h>
#include <stdlib.h>

char* get_operand(char* line, int* i, int line_num, int is_last_operand, int is_first_operand, int* is_empty, int is_data_instruction)
{
	char* str;
	char* op;
	int comma_cnt=0; /*comma count*/

	/*check for commas before first operand*/
	if(is_first_operand){
		ignore_space(line,i);
		if(line[*i] == ','){ /*comma*/	
			fprintf(stderr,"ERROR: in line:%d excessive comma before first operand\n",line_num);
			return NULL;
		}
	}

	/*get operand*/
	str = get_op(line,i,line_num);
	op=str;
	
	if(op==NULL) /*missing operand*/
	{
		if(!is_data_instruction){
			fprintf(stderr,"ERROR: in line %d missing operand\n",line_num);
		}
		return NULL;
	}

	comma_cnt+= comma_count(line, i); /*count commas after operand*/

		

	if(comma_cnt>NUMBER_OF_ALLOWED_CONSECUTIVE_COMMAS)
	{ /*ilegal comma*/
		fprintf(stderr,"ERROR: in line:%d multipule consecetive commas\n",line_num);
		free(str);
		return NULL;
	}

	if(is_last_operand){ /*check for excessive text*/
		if(comma_cnt){
			fprintf(stderr,"ERROR: in line:%d excessive comma\n",line_num);
			free(str);
			return NULL;
		}
		str= get_str(line,i);
		if(str){
			fprintf(stderr,"ERROR: in line:%d excessive text after end of command\n",line_num);
			free(str);
			return NULL;
		}
	}

	if(comma_cnt<NUMBER_OF_ALLOWED_CONSECUTIVE_COMMAS && !is_last_operand && !is_data_instruction)
	{ /*missing comma*/
		fprintf(stderr,"ERROR: in line:%d missing comma\n",line_num);
		free(str);
		return NULL;
	}

	*is_empty = OFF;
	
	return op; /*operand*/
}

int comma_count(char* line, int* i) 
{
	int count=0; /*count commas*/
	ignore_space(line,i);

	while(line[*i] == ',') /*count commas*/
	{
		count++; /*comma found*/
		(*i)++;/*advence index*/
		ignore_space(line,i);/*ignore space chrs*/
	}
	
	return count;	
}

int which_saved_str(char* str, int include_macro)
{
	static char action[NUM_OF_ACTIONS][MAX_ACTION_SIZE+NULL_TERMINATOR_SIZE];
	static char instruction[NUM_OF_INSTRUCTIONS][MAX_INSTRUCTION_SIZE+NULL_TERMINATOR_SIZE];
	int i=0;

	if(str == NULL){ /*in-valid operand*/
		return NOT_FOUND;
	}
	
	/*initilazie action array*/
	strcpy(action[i++], "mov\0");
	strcpy(action[i++], "cmp\0");
	strcpy(action[i++], "add\0");
	strcpy(action[i++], "sub\0");
	strcpy(action[i++], "not\0");
	strcpy(action[i++], "clr\0");
	strcpy(action[i++], "lea\0");
	strcpy(action[i++], "inc\0");
	strcpy(action[i++], "dec\0");
	strcpy(action[i++], "jmp\0");
	strcpy(action[i++], "bne\0");
	strcpy(action[i++], "get\0");
	strcpy(action[i++], "prn\0");
	strcpy(action[i++], "jsr\0");
	strcpy(action[i++], "rts\0");
	strcpy(action[i++], "hlt\0");
	i=0;

	/*initilazie instruction array*/
	strcpy(instruction[i++], ".data\0");
	strcpy(instruction[i++], ".string\0");
	strcpy(instruction[i++], ".struct\0");
	strcpy(instruction[i++], ".entry\0");
	strcpy(instruction[i], ".extern\0");
	
	
	for(i=0;i<NUM_OF_ACTIONS;i++){ /*goes over array of saved strings*/
		if(!strcmp(action[i],str)){
			return i; /*if found return index*/
		}
	}
	
	for(i=0;i<NUM_OF_INSTRUCTIONS;i++){ /*goes over array of saved strings*/
		if(!strcmp(instruction[i],str)){
			return (i+NUM_OF_ACTIONS); /*if found return instruction index*/
		}
	}


	if(include_macro){ /*used to detect macro for pre-assembler*/
		if(!strcmp("macro",str)){ /*check for macro*/
			return MACRO;
		}

		if(!strcmp("endmacro",str)){ /*check for endmacro*/
			return ENDMACRO;
		}
	}
	
	return NOT_FOUND; /*saved word not found*/
}

int is_data(int index)
{
	if(index == DATA || index == STRUCT || index == STRING){
		return TRUE;
	}
	return FALSE;
}

int is_special_label(int index)
{
	if(index == EXTERNAL || index == ENTRY){
		return TRUE;
	}
	return FALSE;
}

int is_immedate_ATM(char* op, int is_instruction)
{
	int size= strlen(op);
	int starting_index = 0; /*starting index of digits #*/
	int i=0;

	if(!is_instruction){ /*ignore #*/
		size--;
		starting_index++;
	}

	/*check for valid size*/
	if(size<IMMEDATE_ATM_MIN_LEN){
		return FALSE; /*operand not large enough*/
	}

	/*ignore size*/
	if(is_sign(op[starting_index])){ /*func can ignore sign*/
		size--; 
		starting_index++;

		if(size<IMMEDATE_ATM_MIN_LEN){
			return FALSE; /*operand not large enough*/
		}
	}

	if(is_instruction && op[0] == '#'){ /*# not expected*/
			return FALSE;
	}
	
	if(!is_instruction && op[0] != '#'){ /*#  expected*/
			return FALSE;
	}

	/*check that all chars are digits*/
	for(i=starting_index; i<size;i++)
	{
		if(!is_digit(op[i])){
			return FALSE;
		}
	}
	return TRUE;
}

int is_struct_ATM(char* op)
{
	int size = strlen(op);
	int i= size -1; /*index of last char in operand*/
	char temp;

	if(size<STRUCT_ATM_MIN_SIZE) /*operand name is not big enough*/
	{
		return FALSE;
	}

	if(op[i] != '1' && op[i] != '2') 
	/*struct has only 2 segmants, number will be the last char in name*/ 
	{
		return FALSE;
	}

	i--; /*index point to point*/

	if(op[i] != '.') /*point must be the chae before last char in name*/
	{
		return FALSE;
	}
	
	temp = op[i]; /*char = '.'*/
	op[i] = 0; /*NULL terminator shorten op to only label name*/

	if(is_legal_label(op, OFF,OFF) == FALSE) /*line number required for printing which disabeld*/ 
	{
		op[i]=temp; /*return op to original state*/
		return FALSE;
	}
	op[i]=temp; /*return op to original state*/
	
	return TRUE;
}

int what_method(char* op, int line_num, int is_instruction)
{
	if(op == NULL){
		fprintf(stderr, "ERROR: missing operand in line %d\n", line_num);
		return NOT_FOUND;
	}


	if(is_struct_ATM(op))
	{ 
		return STRUCT_ATM;
	}
	
	if(is_reg(op))
	{ 
		return REGISTER_ATM;
	}
	
	if(is_immedate_ATM(op,is_instruction))
	{ 
		return IMMEDATE_ATM;
	}
	
	
	if(is_legal_label(op, line_num,ON) == FALSE) /*ilegal label */
	{
		return NOT_FOUND;
	}

	/*operand is a label name*/
	return FORWARD_ATM;
}


int index_to_binary(int index, int move_by)
{
	return (index<<move_by); 
}

char* binary_to_b32(int b2)
{
	static char base_32[] = "!@#$%^&*<>abcdefghijklmnopqrstuv"; /*base 32 digits*/
	char* b32= (char*)calloc(MAX_WORD_SIZE_BASE_32, sizeof(char)); /*to be returned*/
	int base = strlen(base_32);
	int reminder = b2;
	int i=MAX_WORD_SIZE_BASE_32-1; /*index of last char*/

	if(b2> MAX_WORD_VAL){
		return NULL;
	}
	
	while(i>=0) /*non negative index*/
	{
		reminder = b2 % base;
		b2 = (b2/base);
		b32[i--] = base_32[reminder]; /*update index and base 32 number*/
	}

	return b32;
}

int is_legal_label(char* str, int line_num, int message_flag)
{
	int size = strlen(str);
	int i=0;

	if(size>MAX_LABEL_SIZE)
	{
		if(message_flag){
			fprintf(stderr,"EROR: in line %d label '%s' is bigger than allowed\n",line_num, str);
		}
		return FALSE;
	}

	if(is_reg(str)) /*label name is register- ilegal*/
	{
		if(message_flag){
			fprintf(stderr,"EROR: in line %d label '%s' can not be defined as register name\n",line_num, str);
		}
		return FALSE;
	}

	if(which_saved_str(str,OFF) != NOT_FOUND) /*label name is action or macro\endmacro- ilegal*/
	{
		if(message_flag){
			fprintf(stderr,"EROR: in line %d label '%s' can not be defined as instruction or action name\n",line_num, str);
		}
		return FALSE;
	}
	
	for(i=0; i<size; i++){
		if(str[i]==','){ /*check for comma*/
			if(message_flag){
				fprintf(stderr,"EROR: in line %d label '%s'\nlabel name can not have ',' char\n",line_num, str);
			}
			return FALSE;
		}	
	}

	if(str[size-1]=='"' || str[0] == '"'){ /*check for "*/
		if(message_flag){
			fprintf(stderr,"EROR: in line %d label '%s'\nlabel name can not start or end with '%c' char\n",
				line_num, str, '"');
		}
		return FALSE;
	}	

	if(str[0] == '#') /*label name is action or macro\endmacro- ilegal*/
	{
		if(message_flag){
			fprintf(stderr,"ERROR: in line %d label '%s' can not start with '#' char\n",line_num, str);
		}
		return FALSE;
	}
	
	if(is_num(str)) /*label is a number*/
	{
		if(message_flag){
			fprintf(stderr,"EROR: in line %d label '%s' can not be a number\n",line_num, str);
		}
		return FALSE;
	}

	return TRUE;
}

int num_of_operands(int index)
{
	int static table[] ={2,2,2,2,1,1,2,1,1,1,1,1,1,1,0,0,UNLIMITED,1,1,1,1}; 
		/*a table based on assembler's actions and instructions*/
	return table[index];
}










