#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include <stdlib.h>
#include "input.h"
#include "assembler.h"


FILE* open_file(char* file_name, char* name_ending, char* mode)
{
	char* f_name = NULL;	
	FILE* fp = NULL;
	
	if((f_name = (char*)calloc(MAX_FILE_NAME_SIZE, sizeof(char))) ==NULL){ /*allocate memory for file name*/
		fprintf(stderr,"ERROR: failed to allocate memory in assembler\n");
		return NULL;
	}

	/*update name*/
	strcpy(f_name, file_name);
	strcat(f_name, name_ending);
	
	if ((fp = fopen(f_name, mode))!=NULL){ /*open file*/
		return fp;  /*return file poiter*/
	}

	return NULL;
}

char* get_str(char* line, int* position_in_line_pt)
{
	char temp = line[*position_in_line_pt];
	char* str= (char*)calloc(1, sizeof(char)); /*starting size of str*/
	int str_size=0;
	int line_size = (strlen(line)); 
	
	while(!isspace(temp) && *position_in_line_pt<line_size && temp!=EOF ) /*getting all non white chars in a row (a word)*/
	{
		if((str = (char*)realloc (str, (NULL_TERMINATOR_SIZE+(++str_size) * sizeof(char)))) ==NULL){ /* allocating more memory*/
			fprintf(stderr,"failed to allocate memory in get_str()\n");
			return NULL;
		} 
		str[str_size-1] = temp; /* saving input */ 
		temp = line[++(*position_in_line_pt)];
	}
	
	str[str_size] = 0; /*null terminator*/

	if(str_size ==0){ /*free str if not used*/
		free(str);
		str = NULL;
	}
	
	
	

	return str;	
}

char* get_op(char* line, int* position_in_line_pt, int line_num)
{
	char temp = line[*position_in_line_pt];
	char* str= (char*)calloc(1, sizeof(char)); /*starting size of str*/
	int str_size=0;
	int line_size = (strlen(line)); 
	int legal_string = FALSE;
	
	if(temp == '"') /*string*/
	{
		if((str = (char*)realloc (str, (NULL_TERMINATOR_SIZE+(++str_size) * sizeof(char)))) ==NULL){ /* allocating more memory*/
			fprintf(stderr,"failed to allocate memory in get_str()\n");
			return NULL;
		} 
		str[str_size-1] = temp; /* saving input */ 
		temp = line[++(*position_in_line_pt)];
		while(*position_in_line_pt<line_size && temp!=EOF && temp !='\n')
		{
			if(temp == '"'){
				legal_string = TRUE;
				/*save "*/
				if((str = (char*)realloc (str, (NULL_TERMINATOR_SIZE+(++str_size) * sizeof(char)))) ==NULL){ /* allocating more memory*/
					fprintf(stderr,"failed to allocate memory in get_op()\n");
					return NULL;
				} 
				str[str_size-1] = temp; /* saving input */ 
				temp = line[++(*position_in_line_pt)];
				break;
			}
			if((str = (char*)realloc (str, (1+(++str_size) * sizeof(char)))) ==NULL){ /* allocating more memory*/
				fprintf(stderr,"failed to allocate memory in get_str()\n");
				return NULL;
			} 
			str[str_size-1] = temp; /* saving input */ 
			temp = line[++(*position_in_line_pt)];
				
		} /*end loop*/
		str[str_size] = 0; /*end of op*/
		if(!legal_string){
			fprintf(stderr,"ERROR: in line:%d after '%c' expected '%c",line_num,'"', '"' );
			return NULL;
		}
		return str;
	}
	
	while(!isspace(temp) && *position_in_line_pt<line_size && temp!=EOF && temp!=',' ) 
	/*getting all non white chars in a row (a word), not including commas*/
	{
		if((str = (char*)realloc (str, (1+(++str_size) * sizeof(char)))) ==NULL){ /* allocating more memory*/
			fprintf(stderr,"failed to allocate memory in get_str()\n");
			return NULL;
		} 
		str[str_size-1] = temp; /* saving input */ 
		temp = line[++(*position_in_line_pt)];
	}

	str[str_size] = 0; /*end of op*/

	if(str_size ==0){ /*free str if not used*/
		free(str);
		str = NULL;
	}

	return str;
}

char* get_space(char* line, int* position_in_line_pt)
{
	char temp = line[*position_in_line_pt];
	char* str= (char*)calloc(1, sizeof(char)); /*starting size of str*/
	int str_size=0;
	int line_size = (strlen(line)); 

	while(isspace(temp) && *position_in_line_pt<line_size  && temp!=EOF) /*getting all non white chars in a row (a word)*/
	{
		if((str = (char *)realloc (str, ((++str_size) * sizeof(char))))==NULL){ /* allocating more memory*/
			fprintf(stderr,"failed to allocate memory in get_space()\n");
			return NULL;
		} 
		str[str_size-1] = temp; /* saving input */
		temp= line[++(*position_in_line_pt)];
	}
	
	if(str_size ==0){ /*free str if not used*/
		free(str);
		str = NULL;
	}

	return str;	
}



int read_line(FILE* fpt, char** line, int* EOF_flag)
{
	int size=0; /*size of new line, used as an index*/
	char temp; /*temp char*/
	int space_flag=OFF; /*if a word is larger then max line size then no need to un get word*/
	
	
	temp = getc(fpt); /*gat first charecter in line*/
	while(temp !=EOF && temp!='\n' && size<MAX_LINE_SIZE ) /*reads untill end of file, line or max line size*/
	{
		/*if(!is_printable(temp)){
			temp = getc(fpt);
			continue;
		}*/
		if(!space_flag && isspace(temp)){
			space_flag=ON;
		}
		(*line)[size++]=temp; /*update data to current char and update size*/
		temp = getc(fpt); /*gat next charecter in line*/
	}

	
	if(temp==EOF)
	{
		*EOF_flag= ON;
	}

	if(temp!= '\n' && temp!=EOF) /* max size && last char is'nt end of line or file*/
	{ /*max size without end of line char '\n'*/
		
		fprintf(stderr, "%s\n WARNING - line is to big\n", *line); /* send warning */		
		
		size--; /*point to last char*/

		do{ /*unget last word - too big for this line*/
			ungetc(temp, fpt); /*return char to file*/
			(*line)[size--]=RESET_VAL; /*delete char from node*/
			temp = *line[size];
		}while(!isspace(temp) && space_flag); /* un get word unless there is not a white space char in line*/
	
		size++;/* another char- end of line -'\n'*/
		(*line)[++size] = '\n'; /*insert '\n'*/
	}

	
	(*line)[size++] = '\n'; /*insert '\n'*/

	return size;
}


int valid_file_name(char *arg)
{
	if(strlen(arg) > (MAX_FILE_NAME_SIZE - FILE_NAME_END_SIZE)){
		return ERROR;
	}
	else{
		return OK;
	}
}

int ignore_space(char* str, int* i)
{
	char temp;
	
	if(!str){ /*str is null*/
		return ERROR;
	}

	temp = str[*i];
	while(isspace(temp) && temp!='\n' && temp!=EOF)
	{
		temp=str[++(*i)];/*advance index and temp*/
	}
	return *i;
}

int is_white(char* str, int size)
{
	int i=0;
	char temp;
	if (!str) /*str is null*/
	{
		return TRUE;
	}

	for(; i<size; i++) /*goes over all chars*/
	{
		temp =str[i];

		if(!isspace(temp)){
			return FALSE;
		}
	}

	return TRUE; /*non white-char not found*/
}

int is_digit(char c)
{
	if(c<'0' || c>'9') /*out of bounds*/
	{
		return FALSE;
	}
	
	return TRUE;
}

int is_sign(char c)
{
	if(c== '-') 
	{
		return -1; /*negative sign*/
	}
	if(c== '+') 
	{
		return 1; /*positive sign*/
	}
	
	return FALSE; /*sign not found*/
}

int is_label(char* str)
{
	int size = strlen(str);
	if(str[size-1]==':') /*last char is  ':'*/
	{
		return TRUE;
	}
	return FALSE;
}


int is_reg(char* str)
{
	char min = ('0'+MIN_R_NUM); /* range of register*/
	char max = ('0'+MAX_R_NUM);

	if(strlen(str)!=REGISTER_NAME_SIZE)
	{
		return FALSE;
	}

	if(str[0] != 'r') /*r for register*/
	{
		return FALSE;
	}
	
	if(str[1]<min || str[1]>max) /*register number is out of bounds*/
	{
		return FALSE;
	}
	return TRUE; /*legal name*/
}


int is_string(char* str)
{
	int size= strlen(str);
	
	if(size < STRING_MIN_LENGTH){
		return FALSE;
	}
	
	if(str[0] == '"' && str[size-1] == '"'){
		return TRUE;
	}
	return FALSE;
}

int is_instruction(int index)
{
	return (index >=DATA && index<=EXTERNAL);
}

int read_sign(char* str)
{
	/*assume legal op*/
	int sign_index =0;
	
	if(str[0] == '#'){ /*ignore #*/
		sign_index++;
		++str;
	}

	return atoi(str);
}

int is_printable(char ch)
{
	return(ch<= MAX_ASCII_READABLE_RANGE && ch >=MIN_ASCII_READABLE_RANGE);
}

int is_num(char* str)
{
	int size; /*size of string*/
	char temp; /*temp char*/
	int i = 0; /*index*/
	if(!str){ /*NULL*/
		return FALSE;
	}
	
	size = strlen(str); /*update size*/
	temp = str[0]; /*first char*/

	if(is_sign(temp)){ /*ignore first sign*/
		temp = str[++i];
		if(size <= i){ /*only sign*/
			return FALSE;
		}
	}
	
	for(i=0; i<size; i++){
		if(temp >= '9' || temp<= '0'){
			return FALSE; /*not a number*/
		}
	}

	return TRUE;
	
}

int line_comma_count(char* line, int i)
{
	int size;
	int counter = 0;
	int temp;

	if(line ==NULL){
		return counter;
	}
	size = strlen(line) - NULL_TERMINATOR_SIZE;
	
	while(i<size)
	{
		temp = line[i++];
		if(temp == ','){ /*found comma*/
			counter++;
		}
		if(temp == '\n' || temp == EOF || temp == 0){ /*end of line*/
			break;
		}
	}
	return counter;
}




