/*file contain function to help with second pass*/

#include "assembler.h"
#include "label_table.h"

/*file contain function to help with first pass*/

/*recive line and index that point after action, recive action index, label and l_type lists, IC and instruction image
return OK or error, print error message if needed
function code operands binary code to the instruction image, advance IC, uses code_operand()  func
*/
int code_action_arg(char* line, int* i, int index, l_type** lt, label* label, int* IC, word* instruction_image, int line_num);

/*recive operand, l_type and label lists, type of operand(destenation or origin), IC and instruction image
return OK or error, print error message if needed
function code recived operand to instruction image, advance IC
 */
int code_operand(char* operand, label* label, l_type** lt, int is_des, int* IC, word* instruction_image, int line_num);

/*recive operand of type forward ATM, search for label and code operand to instruction image
return OK or ERROR
*/
int code_forward_ATM(char* operand, label* label,l_type**, int* IC, word* instruction_image, int line_num);

/*recive char file name without ending, create .ent,.ext files if needed, create object file, uses function to print to files
return OK or ERROR;
*/
int create_output_files(char* file_name, l_type* lt, label* label, word* data_image, word* instruction_image, int IC, int DC);

/*recive file pointer, print object data from memory
return number of lines printed (not including first line with data size)
 */
int print_ob(FILE *fp, word* data_image, word* instruction_image, int IC, int DC);

