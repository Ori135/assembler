/*this file include general data that is used in the assembler */

/*action index are by order of binary code, instruction index is used by thos order:
.data - 16, .string - 17, .struct - 18, .entry -19, .extern - 20

ATM - Adrres Type Method

*/

#include <stdio.h>

#define ON 1 /*used for flags*/
#define OFF 0 /*used for flags*/
#define OK 1
#define ERROR 0
#define TRUE 1
#define FALSE 0
#define NOT_FOUND -1 /*used to signal a function didn't find thier object*/


#define NULL_TERMINATOR_SIZE 1
#define LOAD_FOR_MEMORY_STARTING_INDEX 100 /*first available memory cell*/
#define NUMBER_OF_ALLOWED_CONSECUTIVE_COMMAS 1 
#define MAX_ACTION_SIZE 3 /*mov, jmp, ext... all three chars*/

#define NUM_OF_ACTIONS 16 /*16 action are in use for assembler*/
#define ACTION_SIZE 3 /* size of action str*/
#define NUM_OF_INSTRUCTIONS 5 /*5 diffrent types of */
#define MAX_INSTRUCTION_SIZE 7 /* max size of instrction str*/

#define ENTRY 19 /*used for for flag in label table*/
#define EXTERNAL 20 /*usd for flag in label table*/
#define DATA 16	/*used to code data to memory*/
#define STRING 17 /*used to code data to memory*/
#define STRUCT 18 /*used to code data to memory*/

#define RELOCATABLE 23 /*used for label 'type' segmant*/
#define MACRO 21 /*index for macro saved word*/
#define ENDMACRO 22 /*index for endmacro word*/
#define MAX_FILE_NAME_SIZE 256 /*max file size*/
#define FILE_NAME_END_SIZE 3 /*ending like .as .am*/
#define MAX_LABEL_SIZE 30 /*used to check max size*/
#define MIN_R_NUM 0 /*used to check if str is a register name*/
#define MAX_R_NUM 7 /*used to check if str is a register name*/
#define REGISTER_NAME_SIZE 2 /*used to check if str is a register name*/
#define STRUCT_POINT_CHAR_INDEX_FROM_END 2 /*struct ATM syntext*/

#define STRING_MIN_LENGTH 3 /*"char" - min legal string*/

#define MEMORY_SIZE 256
#define NUM_OF_BITS_IN_WORD (10) /*10 bit in a word*/
#define STR_FLAG_SIZE 1 /*flag at the end of data_image*/
#define FLAG_INDEX 256 /*index of flag*/
#define END (-2) /*for signal end of array with unknown size*/

#define MAX_WORD_SIZE_BASE_32 2 /*10 bit word corulates to 2 digit base 32 number*/
#define MAX_WORD_VAL (1024) /*all bits are on for 10 bits word*/

/*ATM - Adrres Type Method*/
#define IMMEDATE_ATM 0 /*index for method*/
#define FORWARD_ATM 1 /*index for method*/
#define STRUCT_ATM 2 /*index for method*/
#define REGISTER_ATM 3 /*index for method*/
#define NUM_OF_ATM 4

#define OP_CODE 6 /*for making binary code*/
#define DES_ATM 2 /*for making binary code*/
#define ORIGIN_ATM 4 /*for making binary code*/
#define OPERAND 2 /*for making binary code*/
#define DES_REG 2 /*for making binary code*/
#define ORIGIN_REG 6 /*for making binary code*/

/*used for ARE bits in instructions*/
#define FIRST_WORD_ARE (0) /*first word of action is always absolute*/
#define A_ARE_BITS (0) /*absolute*/
#define R_ARE_BITS (2) /*relocatble*/
#define E_ARE_BITS (1) /*external*/

#define UNLIMITED -1 /*used for num_of_operands fuction*/
#define MAX_ASCII_READABLE_RANGE 126
#define MIN_ASCII_READABLE_RANGE 32


#ifndef WORD
#define WORD
/*used to store memory - hold binary code*/
typedef struct bit_field_word
{
	unsigned int field:NUM_OF_BITS_IN_WORD;
}word;
#endif

/*recive a char pointer to name of file
open source file and create .am file 
copy all data from source file to .am file, dont copy macro declerations, 
replace macro with macro data.
when encounter macro decleration add macro name and data to linked list
when encounter macro, search for it in the linked list and repalce name with data
return OK or ERROR*/
int pre_assembler(char* file_name);

/*recive a char pointer to name of file
open file and alocate memory for data and instruction image, use first and second  pass functions to translate the text to b32, create output files
return OK or ERROR*/
int translate(char* file_name);
