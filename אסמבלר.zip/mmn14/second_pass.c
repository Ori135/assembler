#include <stdlib.h>
#include <string.h>
#include "second_pass.h"
#include "input.h"
#include "data_transfer.h"

int code_action_arg(char* line, int* i, int index, l_type** lt, label* label,int* IC, word* instruction_image, int line_num)
{
	int op_counter = num_of_operands(index);
	char* operand;
	int is_reg_flag=OFF;	
	int flag = OK;
	int is_empty = ON;
	
	(*IC)++;/*next avaliable word*/

	if(op_counter == 0){ /*no need to code operands*/
		if(!is_white((line+*i), (strlen(line)-*i))){ /*if rest of line is not white*/
			fprintf(stderr,"ERROR: in line %d execive text\n", line_num);
			return ERROR;
		}
		return OK;
	}

	if(op_counter == 1){ /*one operand*/
		operand = get_operand(line, i, line_num, TRUE, TRUE,&is_empty, FALSE); /*get operand*/
		flag = (code_operand(operand,label,lt,TRUE, IC, instruction_image, line_num) && flag); /*save operand_code*/
	}
	if(op_counter == 2){ /*two operands*/
		operand = get_operand(line, i, line_num, FALSE, TRUE,&is_empty, FALSE); /*get origin operand*/
	        flag = (code_operand(operand,label,lt,FALSE, IC, instruction_image, line_num) && flag); /*save operand_code*/
		
		if(is_reg(operand)){ /*operand is a register*/
			is_reg_flag = ON; 
		}

		free(operand); /*free operand*/
		operand = get_operand(line, i, line_num, TRUE, FALSE,&is_empty, FALSE); /*get destenation operand*/
		
		if(is_reg(operand) && is_reg_flag){ 
		/*both registers can fit in the same word*/
			(*IC)--; 
		}

		flag = (code_operand(operand, label,lt, TRUE, IC, instruction_image, line_num) && flag);/*save operand_code*/
	}
	free(operand); /*free operand*/
	
	return flag;
}

int code_operand(char* operand, label* label, l_type** lt, int is_des, int* IC, word* instruction_image, int line_num)
{
	int type = what_method(operand, line_num, FALSE); /*ATM*/
	int temp =0; /*hold number*/
	char ch=0;
	int field=NOT_FOUND; /*struct field number*/
	int size = strlen(operand);
	int reg_type =0; /*defoult*/

	if(type == IMMEDATE_ATM){
		temp = read_sign(operand);
		temp = index_to_binary(temp, OPERAND);
		instruction_image[(*IC)].field +=temp;
		instruction_image[(*IC)++].field += A_ARE_BITS;
		return OK;
	}

	if(type == FORWARD_ATM){ /*label*/
		if(code_forward_ATM(operand, label, lt,  IC, instruction_image, line_num) == ERROR){
			return ERROR;
		}
		return OK;
	}
	
	if(type == STRUCT_ATM){ /*struct*/
		field = atoi(operand+sizeof(char)*(size-1)); /*get field num*/
		ch = operand[size-STRUCT_POINT_CHAR_INDEX_FROM_END]; /*expected point*/
		operand[size-STRUCT_POINT_CHAR_INDEX_FROM_END] = 0; /*delete .index*/
		/*code first word*/
		if(code_forward_ATM(operand, label, lt, IC, instruction_image, line_num) == ERROR){ /*same as FORWARD_ATM*/
			return ERROR;
		}
		/*code second word*/
		temp = index_to_binary(field, OPERAND); 
		instruction_image[(*IC)].field +=temp;/*save label adress*/
		instruction_image[(*IC)++].field += A_ARE_BITS; /*absolute*/
	
		/*fix operand*/
		operand[size-STRUCT_POINT_CHAR_INDEX_FROM_END] = ch;
	}
		
	if(type == REGISTER_ATM){
		temp = atoi(operand+ sizeof(char)*(size-1)); /*get register num*/
		/*get register type - origin or destenation*/
		if(is_des){
			reg_type = DES_REG;
		}
		else{
			reg_type = ORIGIN_REG;
		}
		/*code word*/
		temp = index_to_binary(temp, reg_type); 
		instruction_image[(*IC)].field +=temp;/*save label adress*/
		instruction_image[(*IC)++].field += A_ARE_BITS; /*absolute*/
	}
	return OK;	
}

int code_forward_ATM(char* operand, label* label, l_type** lt, int* IC, word* instruction_image, int line_num)
{
	int temp = search_label(label, operand);
	int ARE = R_ARE_BITS; /*defoult for label*/
	int ic = *IC+LOAD_FOR_MEMORY_STARTING_INDEX; /*for .ext file*/

	if(temp == NOT_FOUND){
		fprintf(stderr,"ERROR: in line: %d label '%s' does'nt exist\n",line_num, operand);
		return ERROR;
	}
	if(temp == 0){ /*external*/
		ARE = E_ARE_BITS; /*update ARE bits*/
		if(new_l_type(lt, operand,ic, line_num, EXTERNAL) == ERROR){ /*for .ext file*/
			return ERROR;
		}
	}
	/*save and code word*/
	temp = index_to_binary(temp, OPERAND); 
	instruction_image[(*IC)].field +=temp;/*save label adress*/
	instruction_image[(*IC)++].field += ARE; /*relocatble*/
	return OK;
}


int create_output_files(char* file_name, l_type* lt, label* label, word* data_image, word* instruction_image, int IC, int DC)
{
	char* f_name = NULL;
	FILE* fp = NULL; /*file pointer*/
	
	if(search_type(label, EXTERNAL)) /*create .ext file*/
	{
		if((fp = open_file(file_name, ".ext", "w")) == NULL){ /*open file*/
			return ERROR;
		}
		print_ext(lt, fp); /*print to ext file*/
		fclose(fp); /*close file*/
		free(f_name);
		f_name = NULL;
	}

	if(search_type(label, ENTRY)) /*create ent file*/
	{
		if((fp = open_file(file_name, ".ent", "w")) == NULL){ /*open file*/
			return ERROR;
		}
		print_ent(label, fp); /*print to ent file*/
		fclose(fp); /*close file*/
		free(f_name);
		f_name = NULL;
	}
	
	/*create object file*/
	if((fp = open_file(file_name, ".ob", "w")) == NULL){ /*open file*/
			return ERROR;
	}
	/*print to ob file*/
	print_ob(fp, data_image, instruction_image, IC, DC); 

	fclose(fp); /*close file*/
	free(f_name);
	f_name = NULL;

	return OK;
}

int print_ob(FILE *fp, word* data_image, word* instruction_image, int IC, int DC)
{
	char* ic = NULL; /*hold IC in base 32*/
	char* dc = NULL; /*hold DC in base 32*/
	int ic_zero_deleted = OFF; /*flag*/
	int dc_zero_deleted = OFF; /*flag*/
	int i=0; /*index*/
	int j = LOAD_FOR_MEMORY_STARTING_INDEX; /*index*/
	int count=0; /*number of lines*/
	char* adress=0;/*hold base 32 adress*/
	char* val =0;/*hold base 32 val*/

	/*get base 32 data*/
	ic = binary_to_b32(IC);
	dc = binary_to_b32(DC);	

	/*remove acsses 0*/
	if(ic[0] == '!'){ /*remove 0*/
		ic++;
		ic_zero_deleted = ON;
	}
	if(dc[0] == '!'){ /*remove 0*/
		dc++;
		dc_zero_deleted = ON;
	}

	/*print first line*/
	fprintf(fp,"\t%s %s\n",ic,dc);

	/*restore ic and dc*/
	if(ic_zero_deleted == ON){
		ic--;
	}
	if(dc_zero_deleted == ON){
		dc--;
	}

	free(ic);
	free(dc);

	while(i<IC)
	{
		adress=binary_to_b32(j); /*get adress*/
		val=binary_to_b32(instruction_image[i].field); /*get val*/
		fprintf(fp,"%s %s\n",adress,val); /*print data*/
		/*update index and free data*/
		free(adress);
		free(val);
		i++;
		j++;
		count++;
	}

	i=0;	

	while((data_image[i].field ||data_image[i+1].field) && i< (MEMORY_SIZE-1))
	{
		adress=binary_to_b32(j);/*get adress*/
		val=binary_to_b32(data_image[i].field);/*get val*/
		fprintf(fp,"%s %s\n",adress,val);/*print data*/
		/*update index and free data*/
		free(adress);
		free(val);
		i++;
		j++;
		count++;
	}

	/*if the index before last index is NULL terminator or last index is null terminiator*/
	if((data_image[MEMORY_SIZE-1].field && !data_image[MEMORY_SIZE-2].field) || data_image[FLAG_INDEX].field == ON){
		adress=binary_to_b32(j);/*get adress*/
		val=binary_to_b32(data_image[i].field);/*get val*/
		fprintf(fp,"%s %s\n",adress,val);/*print data*/
		/*update index and free data*/
		free(adress);
		free(val);
		i++;
		j++;
		count++;
	}

	return count;
}

