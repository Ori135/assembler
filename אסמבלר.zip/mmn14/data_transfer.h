/*this file contain functions to handle change form of data
or functions that use relevent data to assembler, for example a table with all action name

data in the assembler goes the following change:

str---->int---->binary---->BASE32 

ATM - Adrres Type Method

*/

/*assembley syntex related*/

/*immedate ATM - #+34*/

#define IMMEDATE_ATM_MIN_LEN 1 /*in immedate adrres type method the operand length is 2 char*/
#define STRUCT_ATM_MIN_SIZE 3 /*s . 1 */

#define MIN_L 1 /*fisr word*/

/* get operand from line and check syntext based on flags that 
represent diffrent type of operands and actions, use line_num to print error if needed
if error found, return NULL, otherwise return the char pointer that hold operand
*/
char* get_operand(char* line, int* i, int line_num, int is_last_operand, int is_first_operand, int* is_empty, int is_data_instruction);

/*
count commas in line from recived index to next non white or comma char
return number of commas found.
assume line end with EOF or \n*/
int comma_count(char* line, int* i);

/*str--->int
recive a pointer to char and a flag
function check if recived string is a saved word, if it is return the index (op-code) of the word.
if macro_only flag is on, only check if word is "macro" or "endmacro"
 */
int which_saved_str(char* str, int include_macro);

/*recive action\instruction index and check if data req instruction, return TRUE or FALSE*/
int is_data(int index);

/*recive action\instruction index and check if entry oor extern  instruction, return TRUE or FALSE*/
int is_special_label(int index);

/*chack if given operand is in immedate ATM,
if instruction, does'nt expect '#'
 return TRUE or FALSE*/
int is_immedate_ATM(char* op, int is_instruction);

/*chack if given operand is in struct ATM, return TRUE or FALSE*/
int is_struct_ATM(char* op);

/*str--->int
func recive operand, return the number of the adress type method
 if ATM not found or op is NULL print error message and return NOT_FOUND*/
int what_method(char* op, int line_num, int is_instruction);

/*recive index of action\instruction, return num of operands
if instruction does'nt have limit of operands, return UNLIMITED
*/
int num_of_operands(int index);

/*
int--->binary
recive an index of an action and return an integer which 'on' 
bits are the same as the wanted for the action or method based on recived 'move_by'
for example, for index 3, which represent action 'sub'and move_by==6 the func will return the integer 0011000000 (in binary)
*/
int index_to_binary(int action_index, int move_by);

/*binary--->base 32
recive a integer that contains a binary number (up to 10 bits) 
return the base32 number as a char pointer
function assume the length of the returned str is max of 2
function use calloc to allocate memory for returned string
*/
char* binary_to_b32(int b2);

/*check if str is a legal label name, using is_reg(char*), which_saved_str(char*, int)
return TRUE if true, else- FALSE
if str is ilegal name print error message if message flag is ON
!!!!!!!!!!!!!!!!note!!!!!!!!!!!!!!
func recive str without ':' endin
*/
int is_legal_label(char* str, int line_num, int message_flag);

