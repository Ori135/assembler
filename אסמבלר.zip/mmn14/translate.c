#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "first_pass.h"
#include "second_pass.h"
#include "input.h"
#include "data_transfer.h"

/*recive file pointer, pointer to label and l_type list head, pointer to instruction and data images, pointer to IC and DC
read from file pointer till end of file line by line, ignore empty line and comment lines - start with ';'.
code to instruction image the first word of every action and update IC.
code all of the data instructions to data image and update DC.
create label table with all labels and special label table.
update data instruction labels to point to the end of instructions.
update all entry labels as entrys using special label table.
if error found - prints error message to stderr and continue till end of file
return OK if no error found, else return ERROR. 
  */
int first_pass(FILE* fp, label** label, l_type** lt, word* data_image, word* instruction_image, int* DC, int* ic);

/*recive file pointer, pointer to label and l_type list head, pointer to instruction and data images
read from file pointer till end of file line by line, ignore empty line and comment lines - start with ';'.
code rest of instruction binary code in instruction image.
update special label table - add usage of extern labels.
if error found - prints error message to stderr and continue till end of file
return OK if no error found, else return ERROR
*/
int second_pass(FILE* fp, label* label, l_type** l_type, word* data_image, word* instruction_image);



/*function call for first pass, if error found stops,
if not, calls for second pass, if no error found make .ob file and if needed .ent and .ext
return ERROR or OK
recive file pointer to .am file and a char pointer with file name without ending
*/
int translate(char* file_name)
{
	label* label = NULL; /*label list*/
	l_type* l_type = NULL; /*list for ext and ent file*/
	word* data_image; /*hold data*/
	word* instruction_image; /*hold instructions*/
	int flag = OK;/*used to stop program*/
	int DC=0; /*data counter*/
	int IC=0; /*instruction counter*/
	FILE* fp=open_file(file_name, ".am", "r");; /*file pointer*/
	
	if(!fp){ /*check file*/
		return ERROR;
	}

	/*allocate memory for data and instruction images*/
	data_image = (word*)calloc(MEMORY_SIZE, sizeof(word));
	if(!data_image){
		fprintf(stderr, "ERROR: failed to allocate memory in translete(FILE*,char*)\n");
		return ERROR;
	}
	
	instruction_image = (word*)calloc(MEMORY_SIZE, sizeof(word));
	if(!instruction_image){
		fprintf(stderr, "ERROR: failed to allocate memory in translete(FILE*,char*)\n");
		return ERROR;
	}


	/*first pass*/
	flag = first_pass(fp, &label, &l_type, data_image, instruction_image, &DC, &IC);
	if(flag == ERROR){
		return flag;
	}

	rewind(fp); /*rewinding fp to point to the start of file*/
	
	flag = second_pass(fp, label, &l_type, data_image, instruction_image);
	if(flag == ERROR){
		return flag;
	}

	create_output_files(file_name,l_type, label, data_image, instruction_image, IC, DC);
	
	/*free memory*/
	delete_l_type_list(l_type);
	delete_label_list(label);	
	free(data_image);
	free(instruction_image);
	
	return OK;
}



int first_pass(FILE* fp, label** label, l_type** lt, word* data_image, word* instruction_image, int* DC, int* IC)
{
	char* line =NULL; /*holds temp line*/
	char* str; /*holds temp word*/
	int i=0; /*position in line*/
	int EOF_found=OFF; /*signal for EOF*/
	int is_label_flag=OFF;/*flag*/
	int line_num=0;
	int action_index =-1;
	int flag = OK; /* will return*/
	char* label_name=NULL; /*hold label name*/
	
	*DC =0; /*data_counter*/
	*IC = 0;/*instruction counter*/

	while(!EOF_found) /*while end of file not found*/
	{ 	
		
		/*reset flags*/
		is_label_flag=OFF;	

		if(*IC+*DC+LOAD_FOR_MEMORY_STARTING_INDEX >MEMORY_SIZE){ /*max memory*/
			fprintf(stderr,"ERROR: in line %d  pc run out of memory\n", line_num);
			return ERROR;
		}
		

		/*allocate memory for line*/
		if((line=(char*)calloc(MAX_LINE_SIZE, sizeof(char)))==NULL){ 
			fprintf(stderr, "failed to allocate memory in first pass\n");
			fclose(fp);
			free(data_image);
			free(instruction_image);
			return ERROR;
		}
		
		/* read line*/
		i = 0; /*new line*/
		read_line(fp, &line, &EOF_found);
		line_num++; /*line number*/

		if(EOF_found && is_white(line, strlen(line))){ /*eof and no line*/
			break;
		}
		
		if(is_white(line, strlen(line))) /*check for empty line*/
		{
			free(line);
			line = NULL;
			continue;
		}
		
		ignore_space(line,&i);
		if(line[i] == ';'){ /*comment line*/
			free(line);
			line = NULL;
			continue;
		}
		
		/*check for label declaraton*/
		str= get_str(line, &i);
		if(is_label(str) == TRUE ){
			str[strlen(str)-1] = 0; /*delete ':'*/
			if(is_legal_label(str, line_num, ON)){
				is_label_flag = ON; /*label found*/
				label_name = str;
				ignore_space(line, &i);
				str= get_str(line, &i); /*next_word*/
			}
			else{
				flag = ERROR;
				free(str);
				free(line);
				line=NULL;
				continue; /*error*/
			}
		}

		/*get action\instruction index*/		
		action_index = which_saved_str(str, OFF); 
		
		if(action_index == NOT_FOUND){ /*ilegal action*/
			fprintf(stderr, "ERROR: in line: %d action '%s' does'nt exist\n", line_num,str);
			flag = ERROR;
			free(line);
			free(str);
			line=NULL;
			continue;
		}
		
		
		if(is_data(action_index)){
			if(is_label_flag){ /*add DATA label*/
				flag = (new_label(label,label_name, *DC, TRUE, RELOCATABLE,FALSE,line_num)&& flag);
				free(label_name);
				label_name=NULL;
			}
			/*code data to data image*/
			flag = (code_data(line, &i, action_index, data_image, DC, line_num)&& flag);
			free(line);
			free(str);
			line=NULL;
			continue;
		}
		
		/*entry or extern instruction*/
		if(is_special_label(action_index)){
			if(is_label_flag){
			fprintf(stderr, "WARNING: in line %d, label in of entry or external instruction is meaningless\n", line_num);
			}
			/*add special label */
			flag=(speical_label_instruction(line, &i, action_index, label, lt, IC, line_num)&& flag);
			free(line);
			free(str);
			line=NULL;
			continue;
		}

		if(is_label_flag == TRUE){ /*add label*/
			flag = (new_label(label,label_name, *IC+LOAD_FOR_MEMORY_STARTING_INDEX, FALSE, RELOCATABLE,FALSE,line_num)&& flag);
			free(label_name);
			label_name=NULL;
		}

		/*action line- save binary code*/
		flag = (code_action_first_word(line, &i, action_index, instruction_image, IC, line_num)&& flag);
	} /*end loop*/

	if(*IC+*DC >MEMORY_SIZE){ /*max memory*/
		fprintf(stderr,"ERROR: in line %d  pc run out of memory\n", line_num);
		return ERROR;
	}

	flag = (update_ent(*label, *lt) && flag); /*update entry labels*/
	update_data(*label, (*IC)+LOAD_FOR_MEMORY_STARTING_INDEX); /*update data labels value*/

	return flag;
}




int second_pass(FILE* fp, label* label, l_type** l_type, word* data_image, word* instruction_image)
{
	char* line =NULL; /*holds temp line*/
	char* str; /*holds temp word*/
	int i=0; /*position in line*/
	int EOF_found=OFF; /*signal for EOF*/
	int IC=0; /*instruction counter*/
	int flag = OK;
	int action_index = NOT_FOUND;
	int line_num = 0;
	
	while(!EOF_found) /*while end of file not found*/
	{ 
		/*allocate memory for line*/
		if((line=(char*)calloc(MAX_LINE_SIZE, sizeof(char)))==NULL){ 
			fprintf(stderr, "failed to allocate memory in first pass\n");
			fclose(fp);
			free(data_image);
			free(instruction_image);
			return ERROR;
		}
		
		/* read line*/
		i = 0; /*new line*/
		read_line(fp, &line, &EOF_found);
		line_num++; /*line number*/

		if(EOF_found && is_white(line, strlen(line))){ /*eof and no line*/
			break;
		}
		
		if(is_white(line, strlen(line))) /*check for empty line*/
		{
			free(line);
			line = NULL;
			continue;
		}
		
		ignore_space(line,&i);
		if(line[i] == ';'){ /*comment line*/
			free(line);
			line = NULL;
			continue;
		}
		
		/*check for label declaraton*/
		str= get_str(line, &i);
		if(is_label(str) == TRUE ){
			ignore_space(line,&i);
			str= get_str(line, &i);
		}
	
		/*get action\instruction index*/		
		action_index = which_saved_str(str, OFF);
		
		if(is_instruction(action_index)){
			free(line);
			free(str);
			continue;
		}
		
		/*code operands*/
		flag = (code_action_arg(line, &i, action_index, l_type, label, &IC, instruction_image, line_num) && flag);
	} /*end while loop*/
	
	return flag;
}






