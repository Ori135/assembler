/*!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!111
	note: need func and header
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!*/

#include "assembler.h"
#include "input.h"
#include "macro.h"
#include "data_transfer.h"

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>

int pre_assembler(char* file_name)
{

	char* name_as=NULL; /*file name with .as ending*/
	char* name_am=NULL; /*file name with .am ending*/
	m_node* head=NULL; /*head of macro list*/
	m_node* temp_m_node; /*temp macro node*/
	int position_in_line; /* index- position in line*/
	FILE* f_am; /*pointer to new file (fileName.am)*/
	FILE* f_as; /*pointer to origin file (fileName.as)*/
	char* line =NULL; /*holds temp line*/
	char* str; /*holds temp word*/
	char* space = NULL; /*hold temp space if needed*/
	int EOF_found = OFF; /*flag to signal EOF*/
	int macro_found = OFF;/*flag to signal macro*/
	int name_found = OFF;/*flag to signal name is valid and found*/
	char* name = NULL; /*hold macro name*/
	char* data_macro=NULL; /*hold macro data*/
	int data_size =0; /*hold data size*/
	int list_size=0;/**number of nodes in list*/
	int special_line =OFF; /* a line with macro decleration or endmacro action*/
	int flag;/*used for while loop*/
	
	/*check for valid file name*/
	if(!valid_file_name(file_name)){
		fprintf(stderr, "invalid file name : %s\n", file_name);
		return ERROR;
	}
	
	if ((name_as=(char*)calloc(MAX_FILE_NAME_SIZE, sizeof(char)))==NULL){ /*allocate memory for file.as name string*/
		fprintf(stderr,"failed to allocate memory in pre assembler\n");
		return ERROR;
	}

	if ((name_am=(char*)calloc(MAX_FILE_NAME_SIZE, sizeof(char)))==NULL){ /*allocate memory for file.as name string*/
		fprintf(stderr,"failed to allocate memory in pre assembler\n");
		return ERROR;
	}

	
	/*update files name*/
	strcpy(name_as, file_name);
	strcpy(name_am, file_name);
	strcat(name_as, ".as");
	strcat(name_am, ".am"); 


	/*open files*/
	if((f_as = fopen(name_as, "r"))==NULL){/*open file for reading*/
		fprintf(stderr, "file '%s' ;not found\n", file_name);
		return ERROR;
	}

	if((f_am = fopen(name_am, "w"))==NULL){ /*create new file for wirting*/
		fprintf(stderr, "can not create file in pre_assembler\n");
		return ERROR;		
	}


	/*free files name*/
	free(name_as);
	free(name_am);
	
	while(!EOF_found) /*while end of file not found*/
	{ 	
		/*allocate memory for line*/
		if((line=(char*)calloc(MAX_LINE_SIZE, sizeof(char)))==NULL){ 
			fprintf(stderr, "failed to allocate memory in pre_assembler\n");
			fclose(f_as);
			fclose(f_am);
			return ERROR;
		}
		
		/* read line*/
		position_in_line = 0; /*new line*/
		read_line(f_as, &line, &EOF_found);

		if(EOF_found && is_white(line, strlen(line))){ /*eof and no line*/
			break;
		}
		
		if(is_white(line, strlen(line))) /*check for empty line*/
		{
			fprintf(f_am, "%s", line); /*print empty line*/
			free(line);
			line = NULL;
			continue;
		}

		/*read space in start of line if exist*/		
		if(isspace(line[position_in_line])){ 
			space = get_space(line, &position_in_line);
			}

		str = get_str(line, &position_in_line); /*get first word*/
		
		/*looking for macro decleration*/
		if((macro_found==OFF) && (which_saved_str(str, ON) == MACRO)){ /*ON argument sent to which_saved_str tell the function to 										only look for macro related words*/
			macro_found=ON; 
			special_line=ON;
			if(space!=NULL){ /*no need for space before macro defenition*/
				free(space);
				space=NULL;
			}
		}


					/*copy data to .am file*/
		if(macro_found==OFF)
		{
			print_space(f_am,space); /*space at start of sentence*/
			flag=ON;

			/*print every word in line to .am file, if word is nacro name print data*/
			while(flag && str!=NULL)
			{
				
				if( line[position_in_line]=='\n' || line[position_in_line]==EOF){ 
					flag=OFF;
				}/*update loop status*/

				data_macro= search_m_node(head, str); /*search for macro name*/
				if(data_macro!=NULL){
					fprintf(f_am,"%s",data_macro); /*print macro data instead of name*/
					space = get_space(line, &position_in_line);
					print_space(f_am,space);
				}
				else{ /*str is not a macro name*/ 
					fprintf(f_am,"%s",str); /*print word and space*/ 
					space = get_space(line, &position_in_line);
					print_space(f_am,space);
				}
				
				if(str!=NULL){
					free(str);
				}
				str = get_str(line, &position_in_line); /*get next word*/

			}
		}



		/*looking for endmacro */ 
		if(macro_found && which_saved_str(str, ON) == ENDMACRO){ /*ON argument sent to which_saved_str tell the function to 										only look for macro related words*/

			/*endmacro found*/ 
			
			special_line=ON;
			macro_found=OFF; 
			name_found = OFF;
			if(space!=NULL){ /*no need for space before macro defenition*/
				free(space);
				space=NULL;
			}
			data_size =0;
		
			/*adding macro to list*/
			if(head==NULL){
				head = create_m_node(name, data_macro);
				head->next = NULL;
			}
			else{
				if(list_size==1){/*temp is not connected to head*/
					temp_m_node= create_m_node(name,data_macro); /*crate new node*/
					head->next=temp_m_node;
				}
				else{
					temp_m_node->next = create_m_node(name,data_macro); /*crate new node*/
					temp_m_node = temp_m_node->next;
				}
			}
			list_size++;
			free(name);
			free(data_macro);
			name=NULL;
			data_macro=NULL;

		}
		
		/* get macro name */ 
		if(macro_found && !name_found){ 

			/*get to next word*/
			space = get_space(line, &position_in_line);
			if(space!=NULL){
				free(space);
				space=NULL;
			}
		
			if((name = get_str(line, &position_in_line))!=NULL){
				if(which_saved_str(name, OFF)!=NOT_FOUND){ /*illegal name - result in name equal to NULL*/
					fprintf(stderr, "illegal macro name: %s\n", name);
					free(name);
					name=NULL;
				}
				name_found = ON;/*update flag*/
			}
		}
		
		/*add new line to macro*/
		if(!special_line && macro_found){ 
			data_size+= MAX_LINE_SIZE;
			if(data_size == MAX_LINE_SIZE) /*first line added to macro*/
			{
				if ( (data_macro = (char*)calloc(data_size, sizeof(char))) != NULL){ /*ALLOCATE MEMORY*/
					strcat(data_macro,line); /*add to line data*/
				} 
				else{
					fprintf(stderr, "eror: failed to allocate memory in pre assembler\n");
				}
			}
			else{ /*not first word*/
				if ( (data_macro = (char*)realloc(data_macro, data_size)) != NULL){ /*ALLOCATE MORE MEMORY*/
					strcat(data_macro,line); /*add to line data*/
				}
				else{
					fprintf(stderr, "eror: failed to allocate memory in pre assembler\n");
				}
			}
		}
			
		/*EOF without endmacro eror*/
		if(EOF_found && macro_found){
			fprintf(stderr,"eror: macro decleration without 'endmacro'\n");
			free(name);
			free(data_macro);
		}
		
		/*end of line, free memory*/ 
		free(line);
		line=NULL;
		if(space!=NULL){ 
			free(space);
			space=NULL;
		}
		if(str!=NULL){ /*no need for space before macro defenition*/
			free(str);
			str=NULL;
		}
		special_line =OFF;
			
	}/*end of while loop*/
	
	free(line);
	fclose(f_as);
	fclose(f_am);
	delete_m_list(head); /*delete list*/

	return OK;
}
