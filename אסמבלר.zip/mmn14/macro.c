#include "assembler.h"
#include "macro.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>


m_node* create_m_node(char* m_name, char* m_data)
{
	m_node* m_pt; /* pointer to new node*/
	int name_size = (NULL_TERMINATOR_SIZE+strlen(m_name)); /*size to be allocated including null terminator*/ 
	int data_size = (NULL_TERMINATOR_SIZE+strlen(m_data)); /*size to be allocated including null terminator*/
	
	if((m_pt=malloc(sizeof(m_node)))==NULL){ /*allocate memory for new node*/
		fprintf(stderr,"failed to allocate memory in create_m_node()\n");
		return NULL; 
	}
	
	if((m_pt->name=(char*)calloc(name_size, sizeof(char)))==NULL){ /*allocate memory for name segment*/
		fprintf(stderr,"failed to allocate memory in create_m_node()\n");
		return NULL; 
	}
	
	if((m_pt->data=(char*)calloc(data_size, sizeof(char)))==NULL){ /*allocate memory for name segment*/
		fprintf(stderr,"failed to allocate memory in create_m_node()\n");
		return NULL; 
	}

	/*fill node with data*/
	strcpy(m_pt->name, m_name);
	strcpy(m_pt->data, m_data);
	m_pt->next = NULL;

	return m_pt;
}

int delete_m_node(m_node* m_node_pt)
{

	if (m_node_pt ==NULL){ /*check that node is not empty*/
		return ERROR;
	}

	/*free memory*/
	free(m_node_pt->name);
	free(m_node_pt->data);
	free(m_node_pt);

	return OK;
}

int delete_m_list(m_node* head)
{
	m_node* temp_1 = head; /*temp node to go over list*/
	m_node* temp_2; /*temp node to go over list, hold next node*/
	int counter=0; /*count num of deleted nodes*/

	if (head == NULL){ /*check that list is not empty*/
		return ERROR;
	}

	temp_2 = temp_1->next;

	while(temp_1 != NULL) /*while list is not empty*/
	{
		delete_m_node(temp_1); /*delete node*/
		temp_1 = temp_2; /*advence temp_1 to temp_2*/
		if(temp_1!=NULL){
			temp_2 = temp_1->next; /*advence temp_2 to next node*/
		}
		counter++; 
	}

	return counter;

}

char* search_m_node(m_node* head, char* m_name)
{
	m_node* temp = head; /*temp node to go over list*/

	if (head == NULL){ /*check that list is not empty*/
		return NULL;
	}

	while (temp!=NULL && strcmp(m_name, temp->name)) /*end of list or macro found*/
	{
		temp = temp->next;/*advence to next node*/
	}
	
	if(temp == NULL){
		return NULL;
	}
	else{
		return temp->data;
	}
}














